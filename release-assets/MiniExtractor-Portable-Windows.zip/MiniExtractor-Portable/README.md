# Mini Extractor Go 2.5 — Background Tray Edition

Mini Extractor runs silently in the Windows tray. Global shortcuts remain active while the main window is hidden.

## Background behavior

- Starts silently after installation and after Windows login.
- Closing or minimizing the UI hides it to the tray.
- Double-click the tray icon to reopen the UI.
- Right-click the tray icon for Open, Area OCR, Image OCR, Color Picker, and Exit.
- The Desktop shortcut reopens the existing background instance instead of starting a duplicate.

## Default shortcuts

| Tool | Shortcut |
|---|---|
| Area OCR | `Ctrl+Shift+T` |
| Image OCR | `Ctrl+Shift+I` |
| Color picker | `Ctrl+Shift+C` |

## Install

1. Close older Mini Extractor versions.
2. Double-click `INSTALL-MINI-EXTRACTOR.cmd`.
3. Use the shortcuts immediately.

The installer creates an automatic-login startup shortcut. Use the included enable/disable helper scripts to change that behavior.

## UI spacing fix

The **Quick actions** panel is taller in this edition. Its border now sits clearly below the color-picker action instead of touching the lower button.

The **Keyboard shortcuts** card and status bar were moved down slightly to preserve consistent spacing and visual separation.

## Quick-actions panel spacing fix v2

The **Quick actions** card is now significantly taller and includes a helper line below the color-picker button. The button remains fully inside the card with visible bottom padding.

The **Keyboard shortcuts** card is moved down to preserve a clear gap between both cards.


## Custom app icon

This build includes a custom app icon used for the installed shortcuts and the Windows tray icon.
